<?php 
    include "./db.php";
    $id = $_POST["idc"];
    if($conexion->query("DELETE FROM panes WHERE id=$id")){
        header("location: inicio.php");
    }
?>