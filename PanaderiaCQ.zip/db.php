<?php 
  $conexion = new mysqli("localhost", "id20768347_admin","Pantheonforever-1","id20768347_panes");
  if($conexion->connect_error){
      die($conexion->connect_error);
  }
?>