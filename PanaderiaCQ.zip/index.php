<?php 
include "./db.php";
if(isset($_POST["nombre"])){
  $respuesta = mysqli_query($conexion, "SELECT * FROM administrador WHERE id=1");
  while($fila=$respuesta->fetch_assoc()){
    if($fila["nombre"]==$_POST["nombre"] && $fila["contraseña"]==$_POST["contraseña"]){
        header("location: inicio.php");
      }
      else{
        echo "<script>alert('Contraseña o usuario incorrectos')</script>";
      }
  }
  $conexion->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
    <div class="filtro">
        <div class="container col-4 general">
          <h1 style="text-align: center;">Panaderia</h1>
        <form method="post">
            <div class="form-floating my-5 px-2">
            <input type="text" class="form-control" id="floatingInput" placeholder="Nombre del usuario" name="nombre">
            <label for="floatingInput">Nombre del usuario</label>
          </div>
          <div class="form-floating px-2 mb-5">
            <input type="password" class="form-control" id="floatingPassword" placeholder="Contraseña del usuario" name="contraseña">
            <label for="floatingPassword">Contraseña del usuario</label>
          </div>
          <div class="btn-group mt-5 offset-2 px-1" role="group" aria-label="Basic mixed styles example">
            <button type="submit" class="btn btn-primary">Sesion Admin</button>
            <a href="./tienda.php" type="submit" class="btn btn-success">Comprar panes</a>
          </div>
        </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>