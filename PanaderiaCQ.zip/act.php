<?php 
      include "./db.php";
      $iden = $_POST["iden"];
      $nuvn = $_POST["nuvnombre"];
      $nuvp = $_POST["nuvprecio"];
      $nuvc = $_POST["nuvcantidad"];
      $conexion->query("UPDATE panes SET nombre='$nuvn', cantidad=$nuvc, precio=$nuvp WHERE id=$iden");
      header("location: inicio.php")
?>