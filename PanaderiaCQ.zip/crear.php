<?php 
    include "./db.php";
    $nombre = $_POST["panombre"];
    $cantidad = $_POST["pancantidad"];
    $precio = $_POST["panprecio"];
    if($conexion->query("INSERT INTO `panes` (`id`, `nombre`, `cantidad`, `precio`) VALUES (NULL, '$nombre', '$cantidad', '$precio')")){
        header("location:inicio.php");
    }
?>
