<?php 
include "./db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>inicio</title>
</head>
<body>
    <div class="filtro">
        <div class="admin row">
            <div class="offset-1 col-4 formulario">
                <h2 style="text-align:center; margin-top:20px;">Ingrese nuevos panes</h2>
                <form action="crear.php" method="post">
                    <div class="form-floating mt-5">
                        <input name="panombre" type="text" class="form-control"  placeholder="">
                        <label for="floatingInput">Nombre del pan</label>
                      </div>
                      <div class="form-floating mt-2">
                        <input name="pancantidad" type="number" class="form-control"placeholder="">
                        <label for="floatingPassword">Cantidad</label>
                      </div>
                      <div class="form-floating mt-2">
                        <input name="panprecio" type="number" class="form-control"placeholder="">
                        <label for="floatingPassword">Precio</label>
                      </div>
                      <button type="submit" class="btn btn-primary offset-4 mt-5">Añadir pan</button>
                </form>
            </div>
            <div class="col-6">
                <table class="table offset-1 bg-gradient" style="text-align:center;">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Nombre</th>
                            <th>cantidad</th>
                            <th>precio</th>
                            <th>Borrar</th>
                            <th>Actualizar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $respuesta = mysqli_query($conexion, "SELECT * FROM panes");
                        while($fila=$respuesta->fetch_assoc()){
                        ?>
                        <tr>
                            <td> <?php echo $fila["id"] ; ?> </td>
                            <td><?php echo $fila["nombre"] ; ?></td>
                            <td><?php echo $fila["cantidad"] ; ?></td>
                            <td><?php echo $fila["precio"] ; ?></td>
                            <td>
                                <form action="borrar.php" method="post">
                                <input name="idc" type="hidden" value="<?php echo $fila["id"] ; ?>">
                                <button type="submit" class="btn btn-outline-danger">Borrar</button>
                                </form>
                            </td>
                            <td>
                                <form action="mod.php" method="post">
                                <input name="idc" type="hidden" value="<?php echo $fila["id"] ; ?>">
                                <button type="submit" class="btn btn-outline-primary">Actualizar</button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>